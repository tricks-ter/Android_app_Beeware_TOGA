"""
This is my first Project for devoloping android app with python
"""

import toga

from toga.style.pack import *


class HelloWorld(toga.App):

    def startup(self):
        self.main_box=toga.Box(style=Pack(direction=COLUMN))

        self.name_label= toga.Label(
            "Enter Your Name : ",
            style=Pack(padding=5,text_align=CENTER)
        )
        self.name_input=toga.TextInput(style=Pack(flex=1))

        self.name_box=toga.Box(style=Pack(direction=ROW,padding=5))
        self.name_box.add(self.name_label)
        self.name_box.add(self.name_input)
        self.button= toga.Button(
            "say Hello",
            on_press=self.sayhello,
            style=Pack(padding_top=35,padding_left=5,padding_right=5)
        )

        self.main_box.add(self.name_box)
        self.main_box.add(self.button)

        self.main_window=toga.MainWindow(title=self.formal_name)
        self.main_window.content=self.main_box
        self.main_window.show()

    def close(self):
        self.exit()

    def greeting(name):
        if name:
            return f"Hello, {name}"
        else:
            return "Hello, stranger"
    def sayhello(self,widget):

        self.main_window.info_dialog(
            f"Hello, {self.name_input.value}",
            "Thanks For trying my First app",

            )
        self.close()









def main():
    return HelloWorld()
