import toga

__version__ = toga._package_version(__file__, __name__)
